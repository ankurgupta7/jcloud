<?php
$dbhost = 'dbase.cs.jhu.edu'; // database host
$dbuser = 'agupta82'; // database user
$dbpass = 'yuxbrtugao'; // database password
$dbname = 'cs41517_agupta82_db'; // database name
?>
